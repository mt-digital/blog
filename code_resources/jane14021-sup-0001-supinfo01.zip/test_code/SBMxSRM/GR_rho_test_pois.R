
library(ggplot2)
library(dirmult)
library(STRAND)
library(rethinking)
library(parallel)
library(rstan)
source("plotting_functions.R")

####### Set parameters
PP = 15
GR_rho_test = seq(-0.8, 0.8, length.out=PP)
G_list = dat_list = vector("list",PP)

for(i in 1:PP){
  set.seed(1)

####### FPR test pars
N_id = 90

sr_mu = c(0,0)  
sr_sigma = c(1.4, 2.1) 
sr_rho = GR_rho_test[i]
dr_mu = c(0,0) 
dr_sigma = 1.6
dr_rho= 0.6 
predictor_1 = rbern(N_id, 0)
sr_effects_1 = c(-0.3, 1.3)

group_probs_block_size = c(0.25, c(0.25, 0.25)*(1-0.25))

B_1 = matrix(-12,nrow=1,ncol=1)
B_2 = matrix(rnorm(9,0,3),nrow=3,ncol=3)
B_3 = matrix(rnorm(4,0,3),nrow=2,ncol=2)

diag(B_2) = diag(B_2) + 4.5
diag(B_3) = diag(B_3) + 4.5

B=list(B_1, B_2, B_3)
 
groups_1 = rep("Any",N_id) 
groups_2 = sample( c("Red","White","Blue") , size=N_id , replace=TRUE , prob=group_probs_block_size )
groups_3 = sample( c("Strange", "Charm") , size=N_id , replace=TRUE , prob=c(0.5,0.5) )

groups = data.frame(Intercept=as.numeric(factor(groups_1)), Merica=as.numeric(factor(groups_2)), Quantum=as.numeric(factor(groups_3)))

G = simulate_sbm_plus_srm_network(N_id = N_id, 
                         B = B, 
                         V=3,
                         groups=groups,                  
                         sr_mu = sr_mu,  
                         sr_sigma = sr_sigma, 
                         sr_rho = sr_rho,
                         dr_mu = dr_mu,  
                         dr_sigma = dr_sigma, 
                         dr_rho = dr_rho,
                         mode="poisson",                  # outcome mode
                         individual_predictors = data.frame(Status=predictor_1),
                         dyadic_predictors = NULL,
                         individual_effects = matrix(sr_effects_1,nrow=2,ncol=1),
                         dyadic_effects = NULL
                         )        

 G$group_ids$Merica = factor(G$group_ids$Merica)
 G$group_ids$Quantum = factor(G$group_ids$Quantum)
 G$group_ids$Intercept = factor(G$group_ids$Intercept)

model_dat = make_strand_data(self_report=list(G$network),  block_covariates=G$group_ids, individual_covariates=data.frame(Status=predictor_1), dyadic_covariates=NULL,  outcome_mode = "poisson",exposure=list(G$samps))

     dat_list[[i]] = model_dat
     G_list[[i]] = G
}


fit_dr_rho = mclapply(1:PP, function(z){

  fit_block_plus_social_relations_model(data=dat_list[[z]],
                             block_regression = ~ Merica + Quantum,
                             focal_regression = ~ 1,
                             target_regression = ~ 1,
                             dyad_regression = ~ 1,
                             mode="mcmc",
                             return_predicted_network=TRUE,
                             stan_mcmc_parameters = list(seed = 1, chains = 1, parallel_chains = 1, refresh = 1, iter_warmup = 1000,
                                                         iter_sampling = 1000, max_treedepth = NULL, adapt_delta = NULL)
                           )
  },
  mc.cores = PP)



stanfit_dr_rho <- vector("list", PP)
for(i in 1:PP)
stanfit_dr_rho[[i]] <- rstan::read_stan_csv(fit_dr_rho[[i]]$fit$output_files())


#save.image(file = "DR_rho.RData")


######################################## Parameter recovery
recov_res_true_m <- matrix(NA,nrow=PP,ncol=9)

recov_res_true_m[,1] <- rep(B_1 + B_2[1,1] + B_3[2,2], PP) 
recov_res_true_m[,2] <- rep(B_1 + B_2[2,1] + B_3[2,2], PP) 
recov_res_true_m[,3] <- rep(dr_sigma, PP)
recov_res_true_m[,4] <- rep(dr_rho, PP)
recov_res_true_m[,5] <- rep(sr_sigma[1],PP)
recov_res_true_m[,6] <- rep(sr_sigma[2],PP)
recov_res_true_m[,7] <- GR_rho_test
recov_res_true_m[,8] <- rep(0, PP)
recov_res_true_m[,9] <- rep(0, PP)

parameter_recovery_points_plots(PP, stanfit_dr_rho, GR_rho_test, recov_res_true_m, "SRR","pois")
parameter_recovery_corrs_plots(PP, stanfit_dr_rho, GR_rho_test, G_list, "SRR","pois")



