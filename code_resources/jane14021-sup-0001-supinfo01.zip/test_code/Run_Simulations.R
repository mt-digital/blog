library(parallel)
library(posterior)
library(cmdstanr)

################################################ SBM
setwd("/home/cody_ross/unit_tests/SBM")

PP = 15
S = 12

# source("block_size_test_bern.R")

files_to_run = c("block_size_test_bern.R", 
                 "block_size_test_binom.R",
                 "block_size_test_pois.R", 
                 "in_block_test_bern.R",
                 "in_block_test_binom.R",
                 "in_block_test_pois.R",
                 "predictor_test_bern.R",
                 "predictor_test_binom.R",
                 "predictor_test_pois.R",
                 "sample_size_test_bern.R",
                 "sample_size_test_binom.R",
                 "sample_size_test_pois.R"
                 )


for(i in 1:S){
source(files_to_run[i])
}

################################################ SRM
setwd("/home/cody_ross/unit_tests/SRM")
library(parallel)
library(posterior)
library(cmdstanr)

##############################

PP = 15
S = 18

files_to_run = c("DR_rho_test_bern.R", 
                 "DR_rho_test_binom.R",
                 "DR_rho_test_pois.R",
                 "DR_sigma_test_bern.R", 
                 "DR_sigma_test_binom.R",
                 "DR_sigma_test_pois.R",
                 "GR_rho_test_bern.R", 
                 "GR_rho_test_binom.R",
                 "GR_rho_test_pois.R", 
                 "GR_sigma_test_bern.R", 
                 "GR_sigma_test_binom.R",
                 "GR_sigma_test_pois.R",
                 "Intercept_test_bern.R",
                 "Intercept_test_binom.R",
                 "Intercept_test_pois.R",
                 "Pred_test_bern.R",
                 "Pred_test_binom.R",
                 "Pred_test_pois.R"
                 )

for(i in 1:S){
source(files_to_run[i])
}

################################################ SBM + SRM
setwd("/home/cody_ross/unit_tests/SBMxSRM")

PP = 15
S = 18

files_to_run = c("DR_rho_test_bern.R", 
                 "DR_rho_test_binom.R",
                 "DR_rho_test_pois.R", 
                 "DR_sigma_test_bern.R", 
                 "DR_sigma_test_binom.R",
                 "DR_sigma_test_pois.R",
                 "GR_rho_test_bern.R", 
                 "GR_rho_test_binom.R",
                 "GR_rho_test_pois.R", 
                 "GR_sigma_test_bern.R", 
                 "GR_sigma_test_binom.R",
                 "GR_sigma_test_pois.R",
                 "IBR_test_bern.R",
                 "IBR_test_binom.R",
                 "IBR_test_pois.R",
                 "SRP_test_bern.R",
                 "SRP_test_binom.R",
                 "SRP_test_pois.R"
                 )


for(i in 1:S){
source(files_to_run[i])
}


