library(ggplot2)
library(dirmult)
library(STRAND)
library(rethinking)
library(parallel)
library(rstan)
source("plotting_functions.R")

####### SBM BLOCK SIZE #######
PP = 15
block_prob_rate_test = seq(0.01, 0.8, length.out=PP)
G_list = dat_list = vector("list",PP)

for(i in 1:PP){
  set.seed(1)

####### n blocks test pars
N_id = 90
group_probs_block_size = c(block_prob_rate_test[i], c(0.25, 0.25)*(1-block_prob_rate_test[i]))
predictor_1 = rbern(N_id, 0)
sr_effects_1 = c(-0.3, 1.3)

B_1 = matrix(-4,nrow=1,ncol=1)
B_2 = matrix(rnorm(9,0,3),nrow=3,ncol=3)
B_3 = matrix(rnorm(4,0,3),nrow=2,ncol=2)

B=list(B_1, B_2, B_3)
 
groups_1 = rep("Any",N_id) 
groups_2 = sample( c("Red","White","Blue") , size=N_id , replace=TRUE , prob=group_probs_block_size )
groups_3 = sample( c("Strange", "Charm") , size=N_id , replace=TRUE , prob=c(0.5,0.5) )

groups = data.frame(Intercept=as.numeric(factor(groups_1)), Merica=as.numeric(factor(groups_2)), Quantum=as.numeric(factor(groups_3)))
groupsf = data.frame(Intercept=factor(groups_1), Merica=factor(groups_2), Quantum=factor(groups_3))

G = simulate_sbm_network(B = B,                    # Block tie probabilities
                     V = 3,                            # Blocking variables
                     groups=groups,                    # Group IDs
                     N_id=N_id,                        # N people 
                     mode="binomial",                 # outcome mode
                     individual_predictors = NULL,     # A matrix of covariates
                     dyadic_predictors = NULL,         # An array of covariates
                     individual_effects = NULL,        # The effects of predictors on sender effects (row 1) and receiver effects (row 2)
                     dyadic_effects = NULL             # The effects of predictors on dyadic ties
                                )


model_dat = make_strand_data(self_report=list(G$network),  block_covariates=groupsf, individual_covariates=data.frame(Status=predictor_1), dyadic_covariates=NULL, outcome_mode = "binomial",exposure=list(G$samps))

     dat_list[[i]] <- model_dat
     G_list[[i]] <- G
}


fit_block_size <- mclapply(1:PP, function(z){

  fit_block_model(data=dat_list[[z]],
                             block_regression = ~ Merica + Quantum,
                             focal_regression = ~ 1,
                             target_regression = ~ 1,
                             dyad_regression = ~ 1,
                             mode="mcmc",
                             stan_mcmc_parameters = list(seed = 1, chains = 1, parallel_chains = 1, refresh = 1, iter_warmup = 1000,
                                                         iter_sampling = 1000, max_treedepth = NULL, adapt_delta = NULL)
                          )
  },
  mc.cores = PP)

stanfit_block_size <- vector("list", PP)
for(i in 1:PP)
stanfit_block_size[[i]] <- rstan::read_stan_csv(fit_block_size[[i]]$fit$output_files())


#save.image(file = "block_size_rate.RData")


############################################## Parameter recovery
recov_res_true_m <- matrix(NA,nrow=PP,ncol=4)

recov_res_true_m[,1] <- rep(B_1 + B_2[1,1] + B_3[2,2], PP) 
recov_res_true_m[,2] <- rep(B_1 + B_2[2,1] + B_3[2,2], PP) 
recov_res_true_m[,3] <- rep(0, PP)
recov_res_true_m[,4] <- rep(0, PP)

parameter_recovery_points_plots(PP, stanfit_block_size, block_prob_rate_test, recov_res_true_m, "BRD","binom")










