library(ggplot2)
library(sna)
library(igraph)
library(GGally)


d = read.table("OBS_data.txt",sep="\t", header=TRUE)
names = c("ANGELE", "ARIELLE", "ATMOSPHERE", "BOBO", "EWINE", "FANA", 
"FELIPE", "FEYA", "HARLEM", "KALI", "LIPS", "LOME", "MAKO", "MALI", 
"MUSE", "NEKKE", "PETOULETTE", "PIPO", "VIOLETTE")

Grooming = matrix(NA, ncol=length(names), nrow=length(names))
Presenting = matrix(NA, ncol=length(names), nrow=length(names))
Threatening = matrix(NA, ncol=length(names), nrow=length(names))
Exposure = matrix(NA, ncol=length(names), nrow=length(names))

colnames(Exposure) = rownames(Exposure) = colnames(Grooming) = rownames(Grooming) = colnames(Presenting) = rownames(Presenting) = colnames(Threatening) = rownames(Threatening) = names

for(i in 1:length(names)){
  for(j in 1:length(names)){
  scrap = d[which(d$Actor==names[i] & d$Recipient==names[j] & d$Behavior == "Grooming"),]
  Grooming[i,j] = dim(scrap)[1]

  scrap = d[which(d$Actor==names[i] & d$Recipient==names[j] & d$Behavior == "Presenting"),]
  Presenting[i,j] = dim(scrap)[1]

  scrap = d[which(d$Actor==names[i] & d$Recipient==names[j] & d$Behavior == "Threatening"),]
  Threatening[i,j] = dim(scrap)[1]

  scrap = d[which(d$Actor==names[i] & d$Recipient==names[j]),]
  Exposure[i,j] = dim(scrap)[1]
}}

Exposure2 = matrix(NA, ncol=length(names), nrow=length(names))

colnames(Exposure2) = rownames(Exposure2) = names
Behavior_Counts = table(d$Actor)[-1]

for(i in 1:length(names)){
  Exposure2[,i] = Behavior_Counts
}

ind = read.csv("MonkeyInfo.csv")

BirthYear = Sex = c()

for(i in 1:length(names)){
  if(length(which(ind$Name==names[i])>0)){
  BirthYear[i] = ind$DOB_Year[which(ind$Name==names[i])]
  Sex[i] = ind$Sex[which(ind$Name==names[i])]
 }
}

# Data from https://onlinelibrary.wiley.com/doi/full/10.1002/ajp.23387
Age = 2020 - BirthYear
Sex[16] = "female"
Age[16] = 3

# Plot
Grooming2 = Grooming/Exposure2
bip = network(Grooming2, names.eval = "weights")
col = c("female"="darkcyan", "male"="darkgoldenrod")
batty = ggnet2(bip,  mode = "fruchtermanreingold", edge.size =8*c(Grooming2[which(Grooming2>0)]), node.size=Age, palette = col, color=Sex, arrow.size = 5, arrow.gap = 0.03) + 
theme(legend.position="none")
ggsave("Baboon_net.pdf", batty, width=5.5, height=5.5)


