


P_se = function(x){
	M_x = mean(x)
    
    if(M_x<0){
	N_x = length(x)
	P_x = length(which(x>0))
    } else{
    N_x = length(x)
	P_x = length(which(x<0))
    }

	return(P_x/N_x)
}

set.seed(1)
# Load libraries
library(STRAND)
library(rethinking)
library(ggplot2)
library(sna)
library(asnipe)

# Make data
N_id = 60
PP = 31
N_samps = 10

# Covariates
Kinship = rlkjcorr( 1 , N_id , eta=1.5 )
Dominant = ceiling(rlkjcorr( 1 , N_id , eta=1.5 ) - 0.1)
Mass = rbern(N_id, 0.4)

groups = sample( c("Red","White","Blue") , size=N_id , replace=TRUE , prob=c(0.5, 0.25, 0.25) )
Blocking =matrix(NA, ncol=N_id,nrow=N_id)
for(i in 1:N_id){
	for(j in 1:N_id){
		Blocking[i,j] = ifelse(groups[i]==groups[j],0,-2)
	}
}

# Organize into list
dyadic_preds = array(NA,c(N_id,N_id,3))

dyadic_preds[,,1] = Kinship
dyadic_preds[,,2] = Dominant
dyadic_preds[,,3] = Blocking


QAP_B = QAP_P = STRAND_B = STRAND_L = STRAND_H = STRAND_P = array(NA, c(N_samps, PP, 3))
kin_effect = seq(-3.5, 3.5, length.out=PP)


for(ss in 1:N_samps){
for(pp in 1:PP){

set.seed(1)
# Set effect sizes
sr_mu = c(0,0)  
sr_sigma = c(2.8, 1.7) 
sr_rho = 0.65
dr_mu = c(0,0) 
dr_sigma = 1.5
dr_rho= 0.67
sr_effects_1 = c(-1.7, 1.2)
dr_effects_1 = c(kin_effect[pp], 0, 1) #c(kin_effect[pp], 0, 1)

#################################################### Simulate SBM + SRM network
G = simulate_srm_network(N_id = N_id, 
                         B = - 5,               
                         sr_mu = sr_mu,  
                         sr_sigma = sr_sigma, 
                         sr_rho = sr_rho,
                         dr_mu = dr_mu,  
                         dr_sigma = dr_sigma, 
                         dr_rho = dr_rho,
                         mode="binomial",                  
                         individual_predictors = data.frame(Mass=Mass),
                         dyadic_predictors = dyadic_preds,
                         individual_effects = matrix(sr_effects_1,nrow=2,ncol=1),
                         dyadic_effects = dr_effects_1
                         )       

Y = G$network/G$samps

set.seed(ss+1234)
scrap_qap = mrqap.dsp(Y ~ Kinship+Dominant, directed="directed")

QAP_B[ss, pp, ] = scrap_qap$coefficients
QAP_P[ss, pp, ] = scrap_qap$P.values


################################################### Organize for model fitting
model_dat = make_strand_data(outcome=list(G$network),  block_covariates=NULL, individual_covariates=data.frame(Mass=Mass), 
                           dyadic_covariates=list(Kinship=Kinship, Dominant=Dominant),  outcome_mode = "binomial", exposure=list(G$samps))

# Model the data with STRAND
fit =  fit_social_relations_model(data=model_dat,
                              focal_regression = ~ 1,
                              target_regression = ~ 1,
                              dyad_regression = ~ Kinship + Dominant,
                              mode="mcmc",
                              stan_mcmc_parameters = list(chains = 1, parallel_chains = 1, refresh = 100,
                                                          iter_warmup = 1000, iter_sampling = 1000,
                                                          max_treedepth = NULL, adapt_delta = 0.9)
)
 Sys.sleep(1.5)

# Check parameter recovery
res = summarize_strand_results(fit)
 Sys.sleep(1.5)

STRAND_B[ss, pp, ] = res$summary[c(8,4,5),2]
STRAND_L[ss, pp, ] = res$summary[c(8,4,5),3]
STRAND_H[ss, pp, ] = res$summary[c(8,4,5),4]

STRAND_P[ss, pp, ] = c(NA,
	P_se(res$sample$srm_model_samples$dyadic_coeffs[,1]),
	P_se(res$sample$srm_model_samples$dyadic_coeffs[,2])
	)


print("iteration done:")
print(pp)

print("sampling rounds:")
print(ss)
}
}

QAP_B_mu = apply(QAP_B,2:3,mean)
QAP_P_mu = apply(QAP_P,2:3,mean)
STRAND_B_mu = apply(apply(STRAND_B,1:3,as.numeric),2:3,mean)   
STRAND_L_mu = apply(apply(STRAND_L,1:3,as.numeric),2:3,mean)
STRAND_H_mu = apply(apply(STRAND_H,1:3,as.numeric),2:3,mean)
STRAND_P_mu = apply(apply(STRAND_P,1:3,as.numeric),2:3,mean)



df_all = data.frame(B = as.numeric(c(STRAND_B_mu[,1],STRAND_B_mu[,2],STRAND_B_mu[,3])), 
	                   L = as.numeric(c(STRAND_L_mu[,1],STRAND_L_mu[,2],STRAND_L_mu[,3])),
	                   H = as.numeric(c(STRAND_H_mu[,1],STRAND_H_mu[,2],STRAND_H_mu[,3])),
	                   Pse = as.numeric(c(STRAND_P_mu[,1],STRAND_P_mu[,2],STRAND_P_mu[,3])),
	                   Q = as.numeric(c(QAP_B_mu[,1],QAP_B_mu[,2],QAP_B_mu[,3])),
	                   P = as.numeric(c(QAP_P_mu[,1],QAP_P_mu[,2],QAP_P_mu[,3])),
	                   KinEffect = as.numeric(rep(kin_effect,3)),
	                   True = c(rep(-4,PP),kin_effect,rep(-1.8,PP)),
	                   Parameter=rep(c("Intercept","Kinship","Dominant"),each=PP))

df_all_2 = df_all[which(df_all$Parameter != "Intercept"),]
df_all_2_long = data.frame(P=c(df_all_2$Pse, df_all_2$P), 
	                       Algorithm=rep( c("STRAND","MRQAP") , each=length(df_all_2$P)), 
	                       KinEffect= c(df_all_2$KinEffect, df_all_2$KinEffect),
	                       True= c(df_all_2$True, df_all_2$True),
	                       Parameter= c(df_all_2$Parameter, df_all_2$Parameter)
	                       )
df_all_2_long$Parameter = ifelse(df_all_2_long$Parameter=="Kinship","Covariate 1","Covariate 2")
df_all_2_long$LT = ifelse(df_all_2_long$Algorithm=="STRAND","longdash","solid")
 testing = ggplot(df_all_2_long)+
    geom_line(aes(x=KinEffect, y=P, color=Algorithm, linetype=LT),size=1.5)+
    geom_hline(yintercept=0.05, linetype="dashed")+
    facet_wrap(Parameter ~ .) +
    scale_colour_manual(values=c("STRAND"="#008B8B","MRQAP"="darkgoldenrod"))+
    theme(legend.position="bottom") +
    theme(legend.title=element_text(size=14), 
          legend.text=element_text(size=14))+
    theme(strip.text.x = element_text(size = 14))+
    theme(axis.text=element_text(size=12),
        axis.title=element_text(size=16))+ scale_linetype_identity() + 
    xlab("True generative value of covariate 1") + ylab("Probability")


ggsave("Compare_QAP_STRAND_N60_Z0.pdf", testing, height=4,width=8)



