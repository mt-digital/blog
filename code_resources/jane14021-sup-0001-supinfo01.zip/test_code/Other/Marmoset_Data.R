
# Load libraries
library(STRAND)
library(reshape2)

library(igraph)
library(reshape2)
library(plyr)
library(kinship2)
library(geosphere)
library(gridExtra)
library(GGally)
library(network)
library(sna)
library(ggplot2)
library(rethinking)
library(kinship2)
library(grid)
library(gridExtra)
library(xtable)

#import data
d = read.csv("DyadData.csv",sep=";")
ind = read.csv("IndividualData.csv",sep=";")

######################################################## High Food
####################################### Dyad Data
d1 = d[which(d$Condition == "D"),]

names = unique(c(d1$ID1,d1$ID2))

Agressed_Events = matrix(NA, nrow=length(names), ncol=length(names))
Exposure = matrix(NA, nrow=length(names), ncol=length(names))

for(i in 1:length(names)){
  for(j in 1:length(names)){
    Agressed_Events[i,j] = sum(d1[which(d1$ID1==names[i] & d1$ID2==names[j]),]$Agression_events)
    Exposure[i,j] = length(d1[which(d1$ID1==names[i] & d1$ID2==names[j]),]$Agression_events)
  }
}

Agressed = ifelse(Agressed_Events/Exposure>0.33,1,0)
Agressed[is.na(Agressed)] = 0 

####################################### Individual Data
Group = Sex  = Rank = c()

for(i in 1:length(names)){
  Group[i] = ind[which(ind$Condition == "D" & ind$Individual==names[i]),]$Group[1]
  Sex[i] = ind[which(ind$Condition == "D" & ind$Individual==names[i]),]$Sex[1]
  Rank[i] = ind[which(ind$Condition == "D" & ind$Individual==names[i]),]$Rank[1]
}

Rank_Diff = matrix(NA, nrow=length(names), ncol=length(names))
No_Oppertunity = matrix(NA, nrow=length(names), ncol=length(names))
for(i in 1:length(names)){
  for(j in 1:length(names)){
    Rank_Diff[i,j] = Rank[i] - Rank[j]
    No_Oppertunity[i,j] = ifelse(Group[i] != Group[j], 1, 0)
  }
}



# Plot
bip = network(Agressed, names.eval = "weights")
col = c("COQ"="#697f4f", "PRI"="#e9d586", "VAC"="#644238", "ALG"="grey39")
batty1 = ggnet2(bip,  mode = "fruchtermanreingold", palette = col, color=Group, arrow.size = 10, arrow.gap = 0.025)  + theme(legend.position="none")
ggsave("Agro_net_CM.pdf", batty1, width=5.5, height=5.5)


######################################################## Low Food
####################################### Dyad Data
d1 = d[which(d$Condition == "A"),]

names = unique(c(d1$ID1,d1$ID2))

Agressed_Events = matrix(NA, nrow=length(names), ncol=length(names))
Exposure = matrix(NA, nrow=length(names), ncol=length(names))

for(i in 1:length(names)){
  for(j in 1:length(names)){
    Agressed_Events[i,j] = sum(d1[which(d1$ID1==names[i] & d1$ID2==names[j]),]$Agression_events)
    Exposure[i,j] = length(d1[which(d1$ID1==names[i] & d1$ID2==names[j]),]$Agression_events)
  }
}

Agressed = ifelse(Agressed_Events/Exposure>0.33,1,0)
Agressed[is.na(Agressed)] = 0 

####################################### Individual Data
Group = Sex  = Rank = c()

for(i in 1:length(names)){
  Group[i] = ind[which(ind$Condition == "A" & ind$Individual==names[i]),]$Group[1]
  Sex[i] = ind[which(ind$Condition == "A" & ind$Individual==names[i]),]$Sex[1]
  Rank[i] = ind[which(ind$Condition == "A" & ind$Individual==names[i]),]$Rank[1]
}

Rank_Diff = matrix(NA, nrow=length(names), ncol=length(names))
No_Oppertunity = matrix(NA, nrow=length(names), ncol=length(names))
for(i in 1:length(names)){
  for(j in 1:length(names)){
    Rank_Diff[i,j] = Rank[i] - Rank[j]
    No_Oppertunity[i,j] = ifelse(Group[i] != Group[j], 1, 0)
  }
}


# Plot
bip = network(Agressed, names.eval = "weights")
col = c("COQ"="#697f4f", "PRI"="#e9d586", "VAC"="#644238", "ALG"="grey39")
batty2 = ggnet2(bip,  mode = "fruchtermanreingold", palette = col, color=Group, arrow.size = 10, arrow.gap = 0.025)  + theme(legend.position="none")
windows();batty2
ggsave("Agro_net_SPP.pdf", batty2, width=5.5, height=5.5)



