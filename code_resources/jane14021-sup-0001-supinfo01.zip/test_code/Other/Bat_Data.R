
# Load libraries
library(STRAND)
library(reshape2)

library(igraph)
library(reshape2)
library(plyr)
library(kinship2)
library(geosphere)
library(gridExtra)
library(GGally)
library(network)
library(sna)
library(ggplot2)
library(rethinking)
library(kinship2)
library(grid)
library(gridExtra)
library(xtable)

#import data
d = read.csv("mouth-licking_observations2012.csv")

d$subject[which(d$subject=="count")] = "thecount"
d$subject[which(d$subject=="lucy ")] = "lucy"

d$donor[which(d$donor=="count")] = "thecount"
d$donor[which(d$donor=="lucy ")] = "lucy"

d = d[which(! d$donor %in% c("","1")),]
d = d[which(! d$subject %in% c("","1")),]

Duration = d$duration.s.
Subject = d$subject
Donor = d$donor


names = unique(c(Subject, Donor))
N = length(names)
Lick = matrix(0, nrow=N, ncol=N)

colnames(Lick) = rownames(Lick) = names

for(i in 1:length(Duration))
Lick[which(names==Donor[i]), which(names==Subject[i])] = Lick[which(names==Donor[i]), which(names==Subject[i])] + Duration[i]

Sex = ifelse(names %in% c("vampirella", "mya", "lucy", "bella" , "veronica" ,  "cerce" ,   "countess" ,  "mina" ,  "dot" ),"Female","Male")


Opportunity = matrix(1, nrow=N, ncol=N)
diag(Opportunity) = 0
colnames(Opportunity) = rownames(Opportunity) = names             
                
Opportunity[which(names=="vampirella"), which(names=="mina")] = Opportunity[which(names=="mina"), which(names=="vampirella")] = 0
Opportunity[which(names=="vampirella"), which(names=="mina")] = Opportunity[which(names=="mina"), which(names=="vampirella")] = 0
Opportunity[which(names=="vampirella"), which(names=="countess")] = Opportunity[which(names=="countess"), which(names=="vampirella")] = 0
Opportunity[which(names=="vampirella"), which(names=="dot")] = Opportunity[which(names=="dot"), which(names=="vampirella")] = 0
Opportunity[which(names=="vampirella"), which(names=="flapper")] = Opportunity[which(names=="flapper"), which(names=="vampirella")] = 0

Opportunity[which(names=="dot"), which(names=="fuschia")] = Opportunity[which(names=="fuschia"), which(names=="dot")] = 0
Opportunity[which(names=="dot"), which(names=="helsing")] = Opportunity[which(names=="helsing"), which(names=="dot")] = 0
Opportunity[which(names=="dot"), which(names=="streblick")] = Opportunity[which(names=="streblick"), which(names=="dot")] = 0
Opportunity[which(names=="dot"), which(names=="maribelo")] = Opportunity[which(names=="maribelo"), which(names=="dot")] = 0

Opportunity[which(names=="dot"), which(names=="thecount")] = Opportunity[which(names=="thecount"), which(names=="dot")] = 0
Opportunity[which(names=="dot"), which(names=="gelfing")] = Opportunity[which(names=="gelfing"), which(names=="dot")] = 0
Opportunity[which(names=="dot"), which(names=="gomez")] = Opportunity[which(names=="gomez"), which(names=="dot")] = 0

Opportunity[which(names=="fuschia"), which(names=="flapper")] = Opportunity[which(names=="flapper"), which(names=="fuschia")] = 0
Opportunity[which(names=="fuschia"), which(names=="speedster")] = Opportunity[which(names=="speedster"), which(names=="fuschia")] = 0

Opportunity[which(names=="streblick"), which(names=="flapper")] = Opportunity[which(names=="flapper"), which(names=="streblick")] = 0
Opportunity[which(names=="streblick"), which(names=="speedster")] = Opportunity[which(names=="speedster"), which(names=="streblick")] = 0

Opportunity[which(names=="helsing"), which(names=="flapper")] = Opportunity[which(names=="flapper"), which(names=="helsing")] = 0
Opportunity[which(names=="helsing"), which(names=="speedster")] = Opportunity[which(names=="speedster"), which(names=="helsing")] = 0

Opportunity[which(names=="maribelo"), which(names=="flapper")] = Opportunity[which(names=="flapper"), which(names=="maribelo")] = 0
Opportunity[which(names=="maribelo"), which(names=="speedster")] = Opportunity[which(names=="speedster"), which(names=="maribelo")] = 0


Opportunity[which(names=="thecount"), which(names=="flapper")] = Opportunity[which(names=="flapper"), which(names=="thecount")] = 0
Opportunity[which(names=="thecount"), which(names=="speedster")] = Opportunity[which(names=="speedster"), which(names=="thecount")] = 0

Opportunity[which(names=="gelfing"), which(names=="flapper")] = Opportunity[which(names=="flapper"), which(names=="gelfing")] = 0
Opportunity[which(names=="gelfing"), which(names=="speedster")] = Opportunity[which(names=="speedster"), which(names=="gelfing")] = 0

Opportunity[which(names=="gomez"), which(names=="flapper")] = Opportunity[which(names=="flapper"), which(names=="gomez")] = 0
Opportunity[which(names=="gomez"), which(names=="speedster")] = Opportunity[which(names=="speedster"), which(names=="gomez")] = 0


Opportunity[which(names=="flapper"), which(names=="fuschia")] = Opportunity[which(names=="fuschia"), which(names=="flapper")] = 0
Opportunity[which(names=="flapper"), which(names=="helsing")] = Opportunity[which(names=="helsing"), which(names=="flapper")] = 0
Opportunity[which(names=="flapper"), which(names=="streblick")] = Opportunity[which(names=="streblick"), which(names=="flapper")] = 0
Opportunity[which(names=="flapper"), which(names=="maribelo")] = Opportunity[which(names=="maribelo"), which(names=="flapper")] = 0

Opportunity[which(names=="flapper"), which(names=="thecount")] = Opportunity[which(names=="thecount"), which(names=="flapper")] = 0
Opportunity[which(names=="flapper"), which(names=="gelfing")] = Opportunity[which(names=="gelfing"), which(names=="flapper")] = 0
Opportunity[which(names=="flapper"), which(names=="gomez")] = Opportunity[which(names=="gomez"), which(names=="flapper")] = 0


Opportunity[which(names=="speedster"), which(names=="fuschia")] = Opportunity[which(names=="fuschia"), which(names=="speedster")] = 0
Opportunity[which(names=="speedster"), which(names=="helsing")] = Opportunity[which(names=="helsing"), which(names=="speedster")] = 0
Opportunity[which(names=="speedster"), which(names=="streblick")] = Opportunity[which(names=="streblick"), which(names=="speedster")] = 0
Opportunity[which(names=="speedster"), which(names=="maribelo")] = Opportunity[which(names=="maribelo"), which(names=="speedster")] = 0

Opportunity[which(names=="speedster"), which(names=="thecount")] = Opportunity[which(names=="thecount"), which(names=="speedster")] = 0
Opportunity[which(names=="speedster"), which(names=="gelfing")] = Opportunity[which(names=="gelfing"), which(names=="speedster")] = 0
Opportunity[which(names=="speedster"), which(names=="gomez")] = Opportunity[which(names=="gomez"), which(names=="speedster")] = 0


rel = as.matrix(read.table("relatedness.csv", sep = ",", row.names = 1, header = TRUE))

colnames(rel) = rownames(rel) = tolower(colnames(rel))

Relatedness = rel[match(names, rownames(rel)),match(names, colnames(rel))]

NoOpportunity = ifelse(Opportunity==0,1,0)



# Plot
Lick2 = round(Lick/60,0)
bip = network(Lick2, names.eval = "weights")
col = c("Female"="#580000", "Male"="gray13")
batty = ggnet2(bip,  mode = "fruchtermanreingold", edge.size = sqrt(c(Lick2[which(Lick2>0)]/60)), palette = col, color=Sex, arrow.size = 5, arrow.gap = 0.03)  + theme(legend.position="none")
ggsave("Bat_net.pdf", batty, width=5.5, height=5.5)



